import * as _angular_core from '@angular/core';

declare class SciFormFieldComponent {
    readonly label: _angular_core.InputSignal<string>;
    readonly direction: _angular_core.InputSignal<"row" | "column">;
    private _focusTrap;
    constructor();
    onLabelClick(): void;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<SciFormFieldComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<SciFormFieldComponent, "sci-form-field", never, { "label": { "alias": "label"; "required": true; "isSignal": true; }; "direction": { "alias": "direction"; "required": false; "isSignal": true; }; }, {}, never, ["*"], true, never>;
}

export { SciFormFieldComponent };
